import {EpictCtrl} from './epict_ctrl';

export {
  EpictCtrl as PanelCtrl
};
