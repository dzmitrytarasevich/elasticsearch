import {ImageItCtrl} from './imageit_ctrl';

export {
  ImageItCtrl as PanelCtrl
};
